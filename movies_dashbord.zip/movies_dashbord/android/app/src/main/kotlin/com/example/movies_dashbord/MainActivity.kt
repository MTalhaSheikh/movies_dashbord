package com.example.movies_dashbord

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
